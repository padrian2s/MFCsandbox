// myDialog.cpp : implementation file
//

#include "stdafx.h"
#include "sortItems.h"
#include "myDialog.h"
#include ".\mydialog.h"


// myDialog dialog

IMPLEMENT_DYNAMIC(myDialog, CDialog)
myDialog::myDialog(CWnd* pParent /*=NULL*/)
	: CDialog(myDialog::IDD, pParent)
{
}

myDialog::~myDialog()
{
}

void myDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(myDialog, CDialog)
	ON_BN_CLICKED(IDC_BUTTON1, OnBnClickedButton1)
END_MESSAGE_MAP()


// myDialog message handlers

BOOL myDialog::OnInitDialog()
{
	CDialog::OnInitDialog();	

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void myDialog::OnBnClickedButton1()
{	
	//AfxEndThread(0);
	PostQuitMessage(0);
}
