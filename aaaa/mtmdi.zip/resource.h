//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by mtmdi.rc
//
#define IDR_MAINFRAME                   2
#define IDS_CANNOT_RUN_ON_16BIT_WINDOWS_LT_4 3
#define IDI_HELLO                       4
#define IDM_BOUNCE                      10
#define IDM_HELLO                       11
#define IDM_BLACK                       20
#define IDM_RED                         21
#define IDM_GREEN                       22
#define IDM_BLUE                        23
#define IDM_WHITE                       24
#define IDM_CUSTOM                      25
#define IDM_FAST                        30
#define IDM_SLOW                        31
#define IDD_ABOUTBOX                    100
#define IDR_BOUNCE                      101
#define IDR_HELLO                       102

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         57666
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
