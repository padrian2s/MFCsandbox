// ResourceManager.cpp: implementation of the CResourceManager class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ResourceManager.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CResourceManager::CResourceManager()
{
	// Init handles
	m_hExternalResource = NULL;
	m_hApplicationResource = NULL;
}

CResourceManager::~CResourceManager()
{
	// Check if handle is valid, free library
	if (m_hExternalResource != NULL)
		FreeLibrary(m_hExternalResource);

	// Init handles
	m_hExternalResource = NULL;
	m_hApplicationResource = NULL;
}

//////////////////////////////////////////////////////////////////////
// Load external resource dll. If file not present or unable to load,
// it returns FALSE. If it is present, it is loaded but does not affect
// the default resource of the application. You should call this if you
// want to manage the current application resource and an external one.

BOOL CResourceManager::Setup(CString sExternalResourceFilePath /* Path of extern resource dll */)
{
	// Store application resource handle
	m_hApplicationResource = AfxGetResourceHandle();

	// Load and set external resource handle if any
	m_hExternalResource = LoadLibrary(sExternalResourceFilePath);

	// Check if external resource could not be loaded, abort
	if (m_hExternalResource == NULL)
		return FALSE;

	// Indicate application resource being used
	return TRUE;
}

//////////////////////////////////////////////////////////////////////
// Load external resource dll and set it as default for application.
// Before setting as default, the current resource handle is stored
// in case when you need to access the resource there.
// If file not present or unable to load, the current application
// resource is being used. 

BOOL CResourceManager::SetupEx(CString sExternalResourceFilePath /* Path of extern resource dll */)
{
	// Store application resource handle
	m_hApplicationResource = AfxGetResourceHandle();

	// Load and set external resource handle if any
	m_hExternalResource = LoadLibrary(sExternalResourceFilePath);

	// Check if external resource could not be loaded, abort
	if (m_hExternalResource == NULL)
		return FALSE;

	// Set new resource handle
	AfxSetResourceHandle(m_hExternalResource);

	// Indicate application resource being used
	return TRUE;
}

//////////////////////////////////////////////////////////////////////
// Get string from string table of current or external resource if any
// If there is an external resource loaded, GetString will retrieve from
// there. If not, it will retrieve from the application default resource.

CString CResourceManager::GetString(UINT uiStringID /* ID of string in string table resource */)
{
	// Check if there is any external resource, set it as default
	if (m_hExternalResource != NULL)
		AfxSetResourceHandle(m_hExternalResource);

	// Init string
	CString sString(_T(""));

	// Load string from string table
	sString.LoadString(uiStringID);

	// Check if an external resource has been set as default, restore original one
	if (AfxGetResourceHandle() == m_hExternalResource)
		AfxSetResourceHandle(m_hApplicationResource);

	// Return string loaded
	return sString;
}