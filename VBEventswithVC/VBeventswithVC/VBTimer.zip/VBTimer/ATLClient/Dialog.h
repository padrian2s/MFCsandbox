// Dialog.h : Declaration of the CDialog

#ifndef __DIALOG_H_
#define __DIALOG_H_

#include "resource.h"       // main symbols
#include <atlhost.h>


__declspec(selectany)_ATL_FUNC_INFO EventNotifyParam={CC_STDCALL,VT_EMPTY,1,(VT_I4)};

class CAtlSink : public IDispEventSimpleImpl<1,CAtlSink,&DIID___clsTimer>
{
public:
/*CAtlSink(_clsTimer *ptr)
{
m_pTimer=ptr;
m_pTimer->AddRef();
DispEventAdvise((IUnknown*) m_pTimer);
}

virtual ~CAtlSink()
{
m_pTimer->Release();
DispEventUnadvise((IUnknown*) m_pTimer);
}
  */
	CAtlSink()
	{


	}
	virtual ~CAtlSink()
	{


	}

void __stdcall evtTick(long *tick)
{
	
AtlTrace("\nReceived Tick : %d",*tick);
}

BEGIN_SINK_MAP(CAtlSink)
SINK_ENTRY_INFO(1,DIID___clsTimer,1,evtTick,&EventNotifyParam)
END_SINK_MAP()

//private:
//	_clsTimer *m_pTimer;
};



/////////////////////////////////////////////////////////////////////////////
// CDialog
class CDialog : 
	public CDialogImpl<CDialog>
{
public:
	CDialog()
	{
	}

	~CDialog()
	{
	}

	enum { IDD = IDD_DIALOG };

BEGIN_MSG_MAP(CDialog)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	COMMAND_ID_HANDLER(IDOK, OnOK)
	COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
	MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
	CenterWindow();	
	timer=NULL;
	HRESULT hr=CoCreateInstance(CLSID_clsTimer,NULL,CLSCTX_INPROC_SERVER,IID__clsTimer,(void**)&timer);
	if(SUCCEEDED(hr))
	{
		m_pSink=new CAtlSink();
		m_pSink->DispEventAdvise(timer);
		timer->prcStartTimer();
		
	}

	return 0;
	}

	LRESULT OnOK(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		EndDialog(wID);
		return 0;
	}

	LRESULT OnCancel(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		EndDialog(wID);
		return 0;
	}
private:
	CAtlSink *m_pSink;
	_clsTimer *timer;
	LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		// TODO : Add Code for message handler. Call DefWindowProc if necessary.
		AtlTrace("Destroyed");
		timer->prcStopTimer();
		if (m_pSink->m_dwEventCookie != 0xFEFEFEFE)
		m_pSink->DispEventUnadvise(timer);
			delete m_pSink;
				
		if(timer)
			timer->Release();

		 	CoUninitialize();
		return 0;
	}
};

#endif //__DIALOG_H_
