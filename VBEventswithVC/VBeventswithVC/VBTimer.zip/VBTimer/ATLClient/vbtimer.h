/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Fri Mar 23 04:19:55 2001
 */
/* Compiler settings for D:\Submission\VBTimer\VBTimer.IDL:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __vbtimer_h__
#define __vbtimer_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef ___clsTimer_FWD_DEFINED__
#define ___clsTimer_FWD_DEFINED__
typedef interface _clsTimer _clsTimer;
#endif 	/* ___clsTimer_FWD_DEFINED__ */


#ifndef ____clsTimer_FWD_DEFINED__
#define ____clsTimer_FWD_DEFINED__
typedef interface __clsTimer __clsTimer;
#endif 	/* ____clsTimer_FWD_DEFINED__ */


#ifndef __clsTimer_FWD_DEFINED__
#define __clsTimer_FWD_DEFINED__

#ifdef __cplusplus
typedef class clsTimer clsTimer;
#else
typedef struct clsTimer clsTimer;
#endif /* __cplusplus */

#endif 	/* __clsTimer_FWD_DEFINED__ */


void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 


#ifndef __VBTimer_LIBRARY_DEFINED__
#define __VBTimer_LIBRARY_DEFINED__

/* library VBTimer */
/* [version][uuid] */ 




EXTERN_C const IID LIBID_VBTimer;

#ifndef ___clsTimer_INTERFACE_DEFINED__
#define ___clsTimer_INTERFACE_DEFINED__

/* interface _clsTimer */
/* [object][oleautomation][nonextensible][dual][hidden][version][uuid] */ 


EXTERN_C const IID IID__clsTimer;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("880CE960-E901-4158-BBAF-875ACAD67EC5")
    _clsTimer : public IDispatch
    {
    public:
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE prcStartTimer( void) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE prcStopTimer( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct _clsTimerVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _clsTimer __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _clsTimer __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _clsTimer __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _clsTimer __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _clsTimer __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _clsTimer __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _clsTimer __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *prcStartTimer )( 
            _clsTimer __RPC_FAR * This);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *prcStopTimer )( 
            _clsTimer __RPC_FAR * This);
        
        END_INTERFACE
    } _clsTimerVtbl;

    interface _clsTimer
    {
        CONST_VTBL struct _clsTimerVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _clsTimer_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _clsTimer_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _clsTimer_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _clsTimer_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _clsTimer_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _clsTimer_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _clsTimer_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define _clsTimer_prcStartTimer(This)	\
    (This)->lpVtbl -> prcStartTimer(This)

#define _clsTimer_prcStopTimer(This)	\
    (This)->lpVtbl -> prcStopTimer(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [id] */ HRESULT STDMETHODCALLTYPE _clsTimer_prcStartTimer_Proxy( 
    _clsTimer __RPC_FAR * This);


void __RPC_STUB _clsTimer_prcStartTimer_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE _clsTimer_prcStopTimer_Proxy( 
    _clsTimer __RPC_FAR * This);


void __RPC_STUB _clsTimer_prcStopTimer_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* ___clsTimer_INTERFACE_DEFINED__ */


#ifndef ____clsTimer_DISPINTERFACE_DEFINED__
#define ____clsTimer_DISPINTERFACE_DEFINED__

/* dispinterface __clsTimer */
/* [nonextensible][hidden][version][uuid] */ 


EXTERN_C const IID DIID___clsTimer;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("62941D50-010C-4928-965D-1F511F0A9FE6")
    __clsTimer : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct __clsTimerVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            __clsTimer __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            __clsTimer __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            __clsTimer __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            __clsTimer __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            __clsTimer __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            __clsTimer __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            __clsTimer __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } __clsTimerVtbl;

    interface __clsTimer
    {
        CONST_VTBL struct __clsTimerVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define __clsTimer_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define __clsTimer_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define __clsTimer_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define __clsTimer_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define __clsTimer_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define __clsTimer_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define __clsTimer_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ____clsTimer_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_clsTimer;

#ifdef __cplusplus

class DECLSPEC_UUID("15B0F9E4-4EC2-46AF-B096-0B89D3780935")
clsTimer;
#endif
#endif /* __VBTimer_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
