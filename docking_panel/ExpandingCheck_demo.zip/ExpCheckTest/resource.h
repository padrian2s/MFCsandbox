//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ExpCheckTest.rc
//
#define IDD_EXPCHECKTEST_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDC_COMBO1                      1000
#define IDC_BUTTON1                     1001
#define IDC_BUTTON2                     1002
#define IDC_BUTTON3                     1003
#define IDC_BUTTON4                     1004
#define IDC_BUTTON5                     1005
#define IDC_BUTTON6                     1006
#define IDC_CHECK1                      1007
#define IDC_EDIT1                       1008
#define IDC_BUTTON7                     1009
#define IDC_CHUNNAMED                   1010
#define IDC_CHNAME                      1012
#define IDC_BUTTON10                    1013
#define IDC_CHTYPE                      1014
#define IDC_STNAME                      1015
#define IDC_STTYPE                      1016
#define IDC_BUTTON8                     1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
