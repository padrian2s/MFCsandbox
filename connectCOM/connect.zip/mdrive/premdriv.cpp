// premdriv.cpp : source file that includes just the standard includes
//  MDrive.pch will be the pre-compiled header
//  premdriv.obj will contain the pre-compiled type information

#include "premdriv.h"
