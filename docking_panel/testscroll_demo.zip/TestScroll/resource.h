//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TestScroll.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_TestScrollTYPE              129
#define IDD_SCROLL_DLG                  130
#define IDC_SCROLLINFO_LB               1000
#define IDC_SCROLL_BR_BTN               1001
#define IDC_SCROLL_TR_BTN               1002
#define IDC_SCROLL_BL_BTN               1003
#define IDC_SCROLL_BL_BTN2              1004
#define IDC_SCROLL_TL_BTN               1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
