Author:
-------
	Saurabh Dasgupta

Notes:
------

Extract all the files to a folder, and then run Setup.bat. This will
register the following activeX controls.

(1)Sample1.ocx
(2)Sample2.ocx


	The application can be run with any registered ActiveX control, not neccessarily
the ones that have been listed above.

