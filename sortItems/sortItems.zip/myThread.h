#pragma once

#include "myDialog.h"

// myThread

class myThread : public CWinThread
{
	DECLARE_DYNCREATE(myThread)

protected:
	myThread();           // protected constructor used by dynamic creation
	virtual ~myThread();

public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	afx_msg void quit(WPARAM w, LPARAM l);
	myDialog *dlg;
protected:
	DECLARE_MESSAGE_MAP()
};


