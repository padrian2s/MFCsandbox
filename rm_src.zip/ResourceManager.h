// ResourceManager.h: interface for the CResourceManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RESOURCEMANAGER_H__018521CF_AEDE_43EC_8BC9_E4295859138F__INCLUDED_)
#define AFX_RESOURCEMANAGER_H__018521CF_AEDE_43EC_8BC9_E4295859138F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CResourceManager  
{
// Operations
public:

	// Constructor
	CResourceManager();

	// Destructor
	virtual ~CResourceManager();

	// Load external resource dll. If file not present or unable to load,
	// it returns FALSE. If it is present, it is loaded but does not affect
	// the default resource of the application. You should call this if you
	// want to manage the current application resource and an external one.
	BOOL Setup(CString);

	// Load external resource dll and set it as default for application.
	// Before setting as default, the current resource handle is stored
	// in case when you need to access the resource there.
	// If file not present or unable to load, the current application
	// resource is being used. 
	BOOL SetupEx(CString);

	// Get string from string table of current or external resource if any
	// If there is an external resource loaded, GetString will retrieve from
	// there. If not, it will retrieve from the application default resource.
	CString GetString(UINT);

// Attributes
private:

	HINSTANCE m_hExternalResource; // Handle to external resource loaded
	HINSTANCE m_hApplicationResource; // Handle to current application resource
};

#endif // !defined(AFX_RESOURCEMANAGER_H__018521CF_AEDE_43EC_8BC9_E4295859138F__INCLUDED_)
