//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Plot.rc
//
#define IDS_PLOT                        1
#define IDD_ABOUTBOX_PLOT               1
#define IDB_PLOT                        1
#define IDI_ABOUTDLL                    1
#define IDS_PLOT_PPG                    2
#define IDS_PLOT_PPG_CAPTION            200
#define IDD_PROPPAGE_PLOT               200
#define IDC_CHECK1                      201
#define IDC_CHECK2                      202

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         203
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
