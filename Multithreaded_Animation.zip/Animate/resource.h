//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDB_BITMAP1                     101
#define IDR_MENU1                       102
#define IDB_BITMAP2                     105
#define IDB_BITMAP3                     106
#define IDB_BITMAP4                     107
#define IDB_BITMAP5                     108
#define IDB_BITMAP6                     109
#define IDB_BITMAP7                     110
#define IDB_BITMAP8                     111
#define IDB_BITMAP9                     112
#define IDB_BITMAP10                    114
#define IDB_BITMAP11                    115
#define ID_THREADS                      40001
#define ID_THREAD                       40001
#define ID_QUIT                         40002
#define ID_Q                            40002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        116
#define _APS_NEXT_COMMAND_VALUE         40005
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
