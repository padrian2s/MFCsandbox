//{{NO_DEPENDENCIES}}
// App Studio generated include file.
// Used by BUTTON.RC
//
// This is a part of the Microsoft Foundation Classes C++ library.
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
// This source code is only intended as a supplement to the
// Microsoft Foundation Classes Reference and the
// Books Online documentation provided with the library.
// See these sources for detailed information regarding the
// Microsoft Foundation Classes product.

#define IDS_BUTTON                      1
#define IDB_BUTTON                      1
#define IDS_BUTTON_PPG                  2
#define IDI_ABOUTDLL                    10
#define IDD_ABOUTBOX_BUTTON             100
#define IDS_BUTTON_PPG_CAPTION          101
#define IDD_PROPPAGE_BUTTON             101
#define IDR_INPLACEMENU                 201
#define IDC_CAPTIONEDIT                 201
#define ID_OPTIONS_OPTION1              32768
#define ID_OPTIONS_OPTION2              32769
#define ID_OPTIONS_OPTION3              32770
#define ID_HELP_BUTTONCONTROL           32771

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32767
#define _APS_NEXT_CONTROL_VALUE         202
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
