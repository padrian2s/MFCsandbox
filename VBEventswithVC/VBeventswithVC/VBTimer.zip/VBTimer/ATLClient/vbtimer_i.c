/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Fri Mar 23 04:19:55 2001
 */
/* Compiler settings for D:\Submission\VBTimer\VBTimer.IDL:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID LIBID_VBTimer = {0x50E28385,0x5386,0x4F35,{0xA3,0xE0,0xA6,0xFE,0x65,0x69,0x9F,0x89}};


const IID IID__clsTimer = {0x880CE960,0xE901,0x4158,{0xBB,0xAF,0x87,0x5A,0xCA,0xD6,0x7E,0xC5}};


const IID DIID___clsTimer = {0x62941D50,0x010C,0x4928,{0x96,0x5D,0x1F,0x51,0x1F,0x0A,0x9F,0xE6}};


const CLSID CLSID_clsTimer = {0x15B0F9E4,0x4EC2,0x46AF,{0xB0,0x96,0x0B,0x89,0xD3,0x78,0x09,0x35}};


#ifdef __cplusplus
}
#endif

